/**
 * 
 */
/**
 * @author Sana REKBI
 *
 */
module ProjetWassim {
	requires java.desktop;
}